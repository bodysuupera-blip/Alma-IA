# ALMA — aplicativo holístico

Projeto Android com experiência de bem-estar, inspiração e autoconhecimento. A identidade foi simplificada para **ALMA**, sem personagens ou conversa com avatares.

## Recursos incluídos
- Mensagem diária de reflexão.
- Reflexões guiadas e mantras/afirmações.
- Mensagens inspiracionais do universo.
- Área de sons com tons puros sintetizados no aparelho (432, 528, 639 e 741 Hz).
- Diário pessoal salvo localmente no dispositivo.
- Ritual de respiração guiada de um minuto.
- Interface em português com visual claro, acolhedor e minimalista.

## Gerar APK pelo GitHub
1. Envie todo o conteúdo deste ZIP para a raiz de um repositório GitHub.
2. Abra a aba Actions.
3. Habilite workflows, se necessário.
4. Execute `ALMA IA - Gerar APK`.
5. Baixe o artefato `ALMA-IA-APK`.

## Observações
Esta versão é um protótipo funcional de interface. Os sons são tons puros gerados pelo aparelho, não gravações de músicas, cantos ou mantras. Para incluir músicas completas, será necessário adicionar gravações próprias/licenciadas ou integrar um catálogo de áudio autorizado. As frequências não devem ser apresentadas como tratamento ou cura comprovada.

O diário fica no armazenamento local do aparelho. Antes de uso comercial, implementar e revisar política de privacidade, consentimento, segurança e controles de exclusão/retensão de dados. O conteúdo não oferece diagnóstico ou tratamento e não substitui acompanhamento profissional.
