# ALMA IA 3.0 — projeto Android inicial

Aplicativo Android com personagens fictícios ilustrados por retratos fotográficos, interface de conversa, integração opcional com Gemini API, reconhecimento de fala do Android e saída de voz pelo mecanismo TTS escolhido no aparelho.

## O que já está nesta versão

- Três personagens com retratos fotográficos fictícios: Dr. Augusto, Dra. Helena e Dr. Gabriel.
- Interface nova, adaptada para celular.
- Integração de conversa com Gemini 3.8 Flash via chave configurada no próprio aparelho.
- Proteção contra envio repetido: bloqueio enquanto aguarda resposta e debounce da mesma mensagem.
- Microfone: reconhece fala e coloca o texto no campo para revisão. O usuário toca em Enviar; não envia automaticamente.
- Diário emocional local no aparelho.
- O app bloqueia a fala se detectar o mecanismo Google TTS. Para saída de voz neural, instale SherpaTTS e selecione-o como mecanismo de texto para voz do Android.

## Gerar APK pelo GitHub

1. Crie um repositório novo chamado `Alma-IA-3.0` (ou use outro nome).
2. Envie o conteúdo desta pasta para a raiz do repositório. Não envie a pasta externa `ALMA_IA_3_0` como uma subpasta: `settings.gradle`, `build.gradle`, `app/` e `.github/` precisam ficar na raiz.
3. Abra a aba **Actions**.
4. Selecione **ALMA IA 3.0 - GERAR APK**.
5. Toque em **Run workflow**.
6. Quando terminar, abra o resultado da execução e baixe o artefato `ALMA-IA-3.0-APK`.

## Configurar a IA

1. Abra o aplicativo e entre em Configurações.
2. Crie uma chave no Google AI Studio: https://aistudio.google.com/app/apikey
3. Cole a chave no aplicativo e salve.
4. A chave é armazenada nas preferências privadas do app neste aparelho. Não a coloque em arquivos do projeto, commits, prints ou repositórios públicos.

A disponibilidade gratuita, os modelos e os limites podem mudar. No plano gratuito, o provedor informa que o conteúdo pode ser usado para melhorar os produtos; não use dados clínicos identificáveis ou informações sigilosas.

## Ativar voz neural sem voz Google

A saída de voz usa o mecanismo TTS selecionado no Android. Para não usar Google TTS:

1. Instale SherpaTTS pelo F-Droid: https://f-droid.org/packages/org.woheller69.ttsengine/
2. Abra SherpaTTS e baixe um modelo de voz em português brasileiro compatível com Piper.
3. Nas configurações Android, procure **Texto para voz** ou **Saída de texto para voz**.
4. Selecione SherpaTTS como mecanismo preferido.
5. Volte ao ALMA IA e teste a resposta falada.

Vozes brasileiras e licenças: https://piperhub.org/pt/voices/language/pt-br/

O mecanismo e os modelos de voz são projetos externos e podem variar conforme aparelho/versão do Android. O app não inclui os modelos de voz dentro do APK, para evitar um APK enorme.

## Importante

- A transcrição do microfone usa o serviço de reconhecimento de fala disponível no Android; isso é separado da voz que lê a resposta.
- Os retratos e personagens são fictícios e gerados por IA. Não representam profissionais reais.
- Este app é um protótipo de apoio ao autoconhecimento, não oferece psicoterapia, diagnóstico ou atendimento de emergência.
- O diário é salvo localmente no WebView e não é criptografado neste protótipo.
- A conversa enviada à Gemini API sai do aparelho e é processada pelo provedor. Leia os termos e a política de privacidade antes de usar.
