package com.almaia.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 41;
    private WebView web;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean listening = false;
    private boolean resultDelivered = false;
    private final ExecutorService network = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(15, 16, 29));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(15, 16, 29));
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AlmaAI");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
    }


    private void initTts() {
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {} }
        ttsReady = false;
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady && tts != null) {
                tts.setLanguage(new Locale("pt", "BR"));
                sendVoiceStatus();
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        initTts();
    }

    private void js(String script) {
        if (web != null) runOnUiThread(() -> web.evaluateJavascript(script, null));
    }

    private void sendVoiceStatus() {
        String engine = tts == null ? "" : String.valueOf(tts.getDefaultEngine());
        boolean google = engine.toLowerCase(Locale.ROOT).contains("google");
        JSONObject info = new JSONObject();
        try { info.put("ready", ttsReady); info.put("engine", engine); info.put("google", google); }
        catch (Exception ignored) {}
        js("window.onVoiceStatus && window.onVoiceStatus(" + JSONObject.quote(info.toString()) + ");");
    }

    private void startListening() {
        runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                js("window.onSpeechError && window.onSpeechError('Permita o uso do microfone e tente novamente.');");
                return;
            }
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                js("window.onSpeechError && window.onSpeechError('Este aparelho não tem um serviço de reconhecimento de fala disponível.');");
                return;
            }
            stopListening();
            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                listening = true;
                resultDelivered = false;
                recognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) { js("window.onSpeechStatus && window.onSpeechStatus('Ouvindo...');"); }
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float rmsdB) {}
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() { js("window.onSpeechStatus && window.onSpeechStatus('Processando fala...');"); }
                    @Override public void onError(int error) {
                        if (!resultDelivered) js("window.onSpeechError && window.onSpeechError('Não consegui entender. Tente novamente ou digite sua mensagem.');");
                        stopListening();
                    }
                    @Override public void onResults(Bundle results) {
                        if (resultDelivered) return;
                        resultDelivered = true;
                        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty()) js("window.onSpeechResult && window.onSpeechResult(" + JSONObject.quote(matches.get(0)) + ");");
                        stopListening();
                    }
                    @Override public void onPartialResults(Bundle partialResults) {}
                    @Override public void onEvent(int eventType, Bundle params) {}
                });
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR");
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                recognizer.startListening(intent);
            } catch (Exception e) {
                js("window.onSpeechError && window.onSpeechError('Não foi possível iniciar o microfone.');");
                stopListening();
            }
        });
    }

    private void stopListening() {
        listening = false;
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    private void speak(String text, String character) {
        runOnUiThread(() -> {
            if (text == null || text.trim().isEmpty()) return;
            if (!ttsReady || tts == null) { js("window.onVoiceStatus && window.onVoiceStatus('{\"ready\":false}');"); return; }
            String engine = String.valueOf(tts.getDefaultEngine()).toLowerCase(Locale.ROOT);
            if (engine.contains("google")) {
                js("window.onVoiceBlocked && window.onVoiceBlocked();");
                return;
            }
            try {
                tts.stop();
                String wanted = "helena".equals(character) ? "dii" : ("gabriel".equals(character) ? "cadu" : "miro");
                if (Build.VERSION.SDK_INT >= 21 && tts.getVoices() != null) {
                    for (Voice voice : tts.getVoices()) {
                        String name = voice.getName().toLowerCase(Locale.ROOT);
                        if (name.contains(wanted) && name.contains("pt")) { tts.setVoice(voice); break; }
                    }
                }
                tts.setSpeechRate(0.94f);
                tts.setPitch("helena".equals(character) ? 1.06f : 0.94f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alma-" + System.currentTimeMillis());
            } catch (Exception e) {
                js("window.onVoiceBlocked && window.onVoiceBlocked();");
            }
        });
    }

    private void askGemini(String historyJson, String character) {
        network.execute(() -> {
            HttpURLConnection conn = null;
            try {
                String key = getSharedPreferences("alma", MODE_PRIVATE).getString("gemini_key", "");
                if (key == null || key.trim().isEmpty()) throw new Exception("Configure sua chave de IA nas configurações do aplicativo.");
                JSONArray history = new JSONArray(historyJson);
                if (history.length() == 0) throw new Exception("Escreva uma mensagem antes de enviar.");
                String name = "helena".equals(character) ? "Dra. Helena" : ("gabriel".equals(character) ? "Dr. Gabriel" : "Dr. Augusto");
                String role = "helena".equals(character)
                    ? "Você é a Dra. Helena, uma personagem fictícia de apoio emocional, acolhedora e empática."
                    : ("gabriel".equals(character) ? "Você é o Dr. Gabriel, personagem fictício de autoconhecimento, direto e gentil." : "Você é o Dr. Augusto, personagem fictício de reflexão inspirada na escuta psicanalítica.");
                String system = role + " Responda em português brasileiro, com linguagem humana, natural e cuidadosa. Faça uma pergunta de reflexão por vez, evite respostas prontas e repetições. Não afirme ser terapeuta humano, não diagnostique, não prescreva medicamentos e não substitua psicólogo, psicanalista ou médico. Se houver risco de autoagressão ou perigo imediato, incentive procurar ajuda humana imediata e serviços de emergência. Seja breve, acolhedor e não prometa cura. O usuário está conversando com " + name + ".";
                JSONObject body = new JSONObject();
                JSONObject sys = new JSONObject(); sys.put("parts", new JSONArray().put(new JSONObject().put("text", system)));
                body.put("system_instruction", sys);
                JSONArray contents = new JSONArray();
                for (int i = Math.max(0, history.length() - 12); i < history.length(); i++) {
                    JSONObject item = history.getJSONObject(i);
                    String roleName = "assistant".equals(item.optString("role")) ? "model" : "user";
                    contents.put(new JSONObject().put("role", roleName).put("parts", new JSONArray().put(new JSONObject().put("text", item.optString("text")))));
                }
                body.put("contents", contents);
                body.put("generationConfig", new JSONObject().put("temperature", 0.78).put("maxOutputTokens", 650));
                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=" + URLEncoder.encode(key.trim(), "UTF-8"));
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(40000); conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) { os.write(data); }
                int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                StringBuilder response = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) response.append(line);
                }
                if (code < 200 || code >= 300) {
                    JSONObject err = new JSONObject(response.toString());
                    String msg = err.optJSONObject("error") == null ? "Falha ao conectar à IA." : err.getJSONObject("error").optString("message", "Falha ao conectar à IA.");
                    throw new Exception(msg);
                }
                JSONObject result = new JSONObject(response.toString());
                JSONArray candidates = result.optJSONArray("candidates");
                if (candidates == null || candidates.length() == 0) throw new Exception("A IA não retornou uma resposta. Tente novamente.");
                String answer = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text", "");
                if (answer.trim().isEmpty()) throw new Exception("A IA retornou uma resposta vazia. Tente novamente.");
                final String finalAnswer = answer.trim();
                js("window.onAIResult && window.onAIResult(" + JSONObject.quote(finalAnswer) + ");");
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "Erro inesperado ao conversar com a IA." : e.getMessage();
                js("window.onAIError && window.onAIError(" + JSONObject.quote(msg) + ");");
            } finally { if (conn != null) conn.disconnect(); }
        });
    }

    private class Bridge {
        @JavascriptInterface public void saveApiKey(String key) {
            getSharedPreferences("alma", MODE_PRIVATE).edit().putString("gemini_key", key == null ? "" : key.trim()).apply();
            js("window.onKeySaved && window.onKeySaved();");
        }
        @JavascriptInterface public void ask(String history, String character) { askGemini(history, character); }
        @JavascriptInterface public void startListening() { MainActivity.this.startListening(); }
        @JavascriptInterface public void stopListeningNow() { stopListening(); }
        @JavascriptInterface public void speak(String text, String character) { MainActivity.this.speak(text, character); }
        @JavascriptInterface public void stopSpeaking() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
        @JavascriptInterface public void checkVoice() { sendVoiceStatus(); }
        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> { try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))); } catch (Exception ignored) {} });
        }
        @JavascriptInterface public void openVoiceSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent("android.speech.tts.engine.INSTALL_TTS_DATA")); }
                catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
            });
        }
        @JavascriptInterface public void openTtsSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
                catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microfone liberado", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onDestroy() {
        stopListening();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        network.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
