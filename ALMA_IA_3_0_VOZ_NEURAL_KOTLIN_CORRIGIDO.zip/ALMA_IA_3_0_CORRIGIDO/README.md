# ALMA IA 3.0 — pacote de integração de voz neural

Projeto Android baseado no ALMA IA V1, com interface 3.0, retratos fotográficos ilustrativos e proteção contra envio duplicado por voz.

## Voz neural incluída no processo de compilação

O workflow do GitHub Actions baixa automaticamente:
- Sherpa-ONNX Android AAR 2.0.3;
- modelo Piper `pt_BR-dii-high` (português brasileiro);
- arquivos auxiliares do modelo.

O modelo é incorporado aos assets do APK durante a compilação. A fala sintetizada usa Sherpa-ONNX/Piper localmente, sem Google Text-to-Speech e sem internet durante a síntese.

## Limitações importantes desta entrega

- O modelo `pt_BR-dii-high` publicado na página oficial informa **um único speaker**. Portanto, nesta entrega os três personagens ainda compartilham a mesma voz-base; há pequena variação de velocidade para Gabriel, não são três identidades vocais independentes.
- A conversa ainda usa respostas demonstrativas do protótipo. A conexão com um serviço de IA conversacional real não está incluída neste ZIP.
- O reconhecimento da fala usa a API de reconhecimento disponível no Android; isso é separado da voz de saída Piper.
- A compilação precisa ser executada no GitHub Actions com acesso à internet para baixar o AAR e o modelo. O ZIP contém o código e o workflow, não os arquivos grandes do motor/modelo.
- Verifique a licença do modelo e as condições do conjunto de voz antes de distribuir comercialmente. O código Sherpa-ONNX e o modelo têm licenças independentes.

## Como compilar

1. Envie todo o conteúdo extraído para a raiz do repositório GitHub.
2. Abra Actions.
3. Execute `ALMA IA 3.0 - Voz Neural e APK`.
4. Baixe o artefato `ALMA-IA-3.0-APK-VOZ-NEURAL` quando a execução terminar com sucesso.

A voz só estará realmente dentro do APK se o workflow terminar sem erros e se o APK gerado instalar e reproduzir áudio no aparelho.
