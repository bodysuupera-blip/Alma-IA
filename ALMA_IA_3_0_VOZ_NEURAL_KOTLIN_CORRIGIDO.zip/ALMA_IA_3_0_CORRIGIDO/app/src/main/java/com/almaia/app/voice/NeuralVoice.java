package com.almaia.app.voice;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.util.Log;
import com.k2fsa.sherpa.onnx.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Piper/Sherpa-ONNX Brazilian Portuguese neural TTS. Model files are packaged by CI. */
public final class NeuralVoice {
    private static final String TAG = "AlmaNeuralVoice";
    private final Context context;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private OfflineTts tts;
    private MediaPlayer player;
    private volatile boolean ready = false;

    public NeuralVoice(Context context) { this.context = context.getApplicationContext(); }

    @JavascriptInterface public void speak(String text, String character) {
        if (text == null || text.trim().isEmpty()) return;
        final String safe = text.trim();
        worker.execute(() -> {
            try {
                ensureModel();
                stopPlayer();
                GenerationConfig gen = new GenerationConfig();
                gen.setSid(0);
                // The selected pt-BR model currently has one speaker. Character-specific
                // voice identities require additional separately licensed voice models.
                gen.setSpeed("gabriel".equals(character) ? 1.04f : 0.96f);
                GeneratedAudio audio = tts.generateWithConfigAndCallback(safe, gen, samples -> 1);
                File wav = new File(context.getCacheDir(), "alma-answer.wav");
                if (!audio.save(wav.getAbsolutePath())) throw new IOException("Não foi possível salvar o áudio");
                main.post(() -> play(wav));
            } catch (Throwable e) {
                Log.e(TAG, "Falha na voz neural", e);
                main.post(() -> evaluate("window.onAlmaVoiceError && window.onAlmaVoiceError()"));
            }
        });
    }

    private void ensureModel() throws Exception {
        if (ready && tts != null) return;
        File dir = new File(context.getFilesDir(), "pt_BR_dii_high");
        copyAssetTree("tts_model", dir);
        File model = new File(dir, "pt_BR-dii-high.onnx");
        File tokens = new File(dir, "tokens.txt");
        File espeak = new File(dir, "espeak-ng-data");
        if (!model.isFile() || !tokens.isFile() || !espeak.isDirectory())
            throw new FileNotFoundException("Modelo Piper pt-BR não foi incluído no APK");
        OfflineTtsVitsModelConfig vits = new OfflineTtsVitsModelConfig();
        vits.setModel(model.getAbsolutePath());
        vits.setTokens(tokens.getAbsolutePath());
        vits.setDataDir(espeak.getAbsolutePath());
        OfflineTtsModelConfig modelConfig = new OfflineTtsModelConfig();
        modelConfig.setVits(vits);
        modelConfig.setNumThreads(2);
        OfflineTtsConfig config = new OfflineTtsConfig();
        config.setModel(modelConfig);
        config.setMaxNumSentences(1);
        tts = new OfflineTts(context.getAssets(), config);
        ready = true;
    }

    private void copyAssetTree(String asset, File dest) throws IOException {
        String[] children;
        try { children = context.getAssets().list(asset); }
        catch (IOException e) { throw e; }
        if (children == null || children.length == 0) {
            File parent = dest.getParentFile(); if (parent != null) parent.mkdirs();
            try (InputStream in = context.getAssets().open(asset); OutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return;
        }
        if (!dest.exists()) dest.mkdirs();
        for (String child : children) copyAssetTree(asset + "/" + child, new File(dest, child));
    }

    private void play(File wav) {
        try {
            stopPlayer();
            player = new MediaPlayer();
            player.setDataSource(wav.getAbsolutePath());
            player.setOnCompletionListener(mp -> { mp.release(); if (player == mp) player = null; });
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnErrorListener((mp, what, extra) -> { mp.release(); player = null; return true; });
            player.prepareAsync();
            evaluate("window.onAlmaVoiceStarted && window.onAlmaVoiceStarted()");
        } catch (Exception e) { Log.e(TAG, "Erro ao reproduzir voz", e); }
    }
    private void stopPlayer() {
        if (player != null) { try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {} try { player.release(); } catch (Exception ignored) {} player = null; }
    }
    private void evaluate(String js) { /* WebView callback is optional; playback remains native. */ }
    public void release() { worker.execute(() -> { stopPlayer(); if (tts != null) { tts.release(); tts = null; } }); worker.shutdown(); }
}
