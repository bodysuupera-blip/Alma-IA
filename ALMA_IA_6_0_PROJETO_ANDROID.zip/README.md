# ALMA IA 6.0 — Projeto Android

Baseado no projeto V1 e na interface V3 enviada. Mantém os retratos dos três personagens fictícios e os módulos de diário/reflexão.

## Alterações da versão 6.0
- Interface identificada como ALMA IA 6.0.
- Retratos dos três personagens mantidos.
- Personagens respondem somente por texto; nenhuma síntese de voz é acionada.
- Reconhecimento de fala nativo Android por `SpeechRecognizer`, com pedido de permissão em tempo de execução. O texto reconhecido é colocado no campo para revisão e envio manual.
- Histórico de conversa separado por personagem, salvo localmente.
- Respostas locais com variação e contexto básico para não repetir sempre a mesma frase.

## Limitação importante sobre IA
Este ZIP não contém uma conexão com um modelo generativo remoto. As respostas locais são contextuais, mas não equivalem a uma conversa livre com uma IA real. Para isso, é necessário um backend HTTPS seguro ligado a um provedor de IA, com a chave guardada no servidor (nunca no APK).

## Gerar APK no GitHub
1. Extraia todo o conteúdo deste ZIP na raiz do repositório Android `Alma-IA`, mantendo a estrutura de pastas.
2. Faça commit.
3. Abra Actions e execute `ALMA IA 6.0 - GERAR APK`.
4. Baixe o artefato `ALMA-IA-6.0-APK`.

O reconhecimento de voz depende de o aparelho ter um serviço de reconhecimento instalado e, em muitos aparelhos, conexão de internet. O app não envia nem salva áudio; recebe o texto retornado pelo serviço Android.

O ALMA IA é uma ferramenta de reflexão e não realiza diagnóstico nem substitui atendimento profissional.
