# ALMA IA 6.0 — Projeto Android

Esta é a versão 6.0 real do projeto. O aplicativo exibe ALMA IA 6.0 na tela e usa `versionCode 6` / `versionName 6.0`.

- Retratos dos três personagens fictícios: Dr. Augusto, Dra. Helena e Dr. Gabriel.
- Personagens respondem somente por texto.
- Reconhecimento de voz nativo Android; o usuário dita, revisa o texto e toca em Enviar.
- Histórico local por personagem.
- Respostas locais variadas e contextualizadas.

**Limitação:** ainda não existe backend conectado a um modelo generativo. As respostas locais não equivalem a uma IA conversacional livre.

## GitHub Actions
Envie o conteúdo deste projeto para a raiz do repositório, incluindo `ALMA_IA_6_0_PROJETO_ANDROID.zip` na raiz, e execute `ALMA IA 6.0 - GERAR APK`. O artefato correto terá o nome `ALMA-IA-6.0-APK-v6`.
