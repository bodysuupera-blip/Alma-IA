# ALMA IA 7.1 — Edição Profissional

Projeto Android reestruturado com interface azul neon, retratos ilustrativos de aparência fotográfica para os três personagens, chat exclusivamente por texto, histórico local e backend separado para a API de IA.

## Estrutura

- `app/`: aplicativo Android (WebView) e interface local.
- `app/src/main/assets/images/`: retratos ilustrativos dos personagens.
- `backend/`: servidor Node.js que protege a chave da API e chama a OpenAI Responses API.
- `.github/workflows/build-apk.yml`: workflow de compilação do APK.
- `render.yaml`: configuração inicial de publicação do backend no Render.

## Gerar APK pelo GitHub

1. Extraia o conteúdo deste ZIP.
2. Envie todos os arquivos e pastas para a raiz do repositório GitHub, preservando `.github`.
3. O workflow procura o arquivo `ALMA_IA_7_1_PROFISSIONAL.zip` na raiz. Mantenha também este ZIP original na raiz do repositório.
4. Abra Actions e execute `ALMA IA 7.1 - GERAR APK`.
5. Baixe o artefato `ALMA-IA-7.1-APK-PROFISSIONAL`.

## Ativar as respostas com IA real (etapa obrigatória)

O APK não contém uma chave de API e não deve conter. O servidor precisa ser publicado separadamente:

1. Publique a pasta `backend` em um serviço Node.js HTTPS, por exemplo Render.
2. Configure no painel do servidor a variável secreta `OPENAI_API_KEY` com sua chave da plataforma OpenAI. Nunca coloque essa chave no APK, no GitHub ou no campo de endereço do aplicativo.
3. Opcionalmente configure `OPENAI_MODEL`. O padrão deste projeto é `gpt-6.2-astra`; use um modelo habilitado para sua conta de API.
4. Quando o servidor estiver online, abra Ajustes no aplicativo e informe o endereço HTTPS do servidor, por exemplo `https://seu-servico.onrender.com`.
5. Toque em “Testar conexão”. O endereço deve responder em `/health`.

O backend usa `POST /v1/responses` da OpenAI, mantém a chave no servidor e recebe o histórico recente da conversa. O uso da API pode gerar cobrança separada da assinatura do ChatGPT.

## Limitações e segurança

- A IA real só responderá depois que o backend for publicado e receber uma chave válida.
- As imagens são retratos ilustrativos gerados para os personagens fictícios; não representam profissionais reais.
- O histórico fica no armazenamento local do aparelho e pode ser apagado em Histórico.
- O servidor não foi publicado automaticamente por este ZIP.
- O produto é apoio de reflexão, não substitui terapia, diagnóstico, atendimento médico ou serviços de emergência.
