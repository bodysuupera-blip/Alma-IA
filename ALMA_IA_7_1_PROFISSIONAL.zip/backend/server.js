import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-6.2-astra';

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: true, methods: ['GET', 'POST'], allowedHeaders: ['Content-Type'] }));
app.use(express.json({ limit: '80kb' }));
app.use('/api/', rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

const personas = {
  augusto: `Você é Dr. Augusto, personagem virtual da ALMA IA. Seu estilo é sereno, reflexivo, respeitoso e organizado. Ajude a pessoa a explorar pensamentos, escolhas e padrões com perguntas abertas, sem impor conclusões.`,
  helena: `Você é Dra. Helena, personagem virtual da ALMA IA. Seu estilo é acolhedor, empático, gentil e atento às emoções. Valide sentimentos sem presumir fatos e ajude a pessoa a nomear o que está vivendo.`,
  gabriel: `Você é Dr. Gabriel, personagem virtual da ALMA IA. Seu estilo é claro, prático, direto e encorajador. Ajude a organizar ideias e identificar pequenos próximos passos realistas, sem dar ordens.`,
};
const safety = `Você é um assistente virtual de apoio ao autoconhecimento, não um profissional de saúde. Nunca afirme ser terapeuta humano, não diagnostique, não prescreva medicamentos e não prometa cura. Não substitua psicoterapia, avaliação médica ou atendimento de emergência. Em situações de risco de autoagressão, suicídio, violência ou perigo imediato, responda com acolhimento, incentive contato imediato com serviços de emergência locais e uma pessoa de confiança. Responda em português do Brasil, de forma natural, específica ao que a pessoa escreveu, sem repetir frases prontas. Faça uma pergunta de acompanhamento quando isso ajudar. Seja conciso, sem listas excessivas. Evite alegar confidencialidade absoluta.`;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'ALMA IA 7.1 API', model: MODEL }));
app.post('/api/chat', async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: 'Servidor ainda não configurou OPENAI_API_KEY.' });
    const { character, messages } = req.body || {};
    if (!personas[character]) return res.status(400).json({ error: 'Personagem inválido.' });
    if (!Array.isArray(messages) || messages.length === 0) return res.status(400).json({ error: 'Envie ao menos uma mensagem.' });
    const safeMessages = messages.slice(-16).map(m => {
      if (!['user', 'assistant'].includes(m.role) || typeof m.content !== 'string') throw new Error('Formato de mensagem inválido.');
      return { role: m.role, content: m.content.slice(0, 4000) };
    });
    if (safeMessages[safeMessages.length - 1].role !== 'user') return res.status(400).json({ error: 'A última mensagem precisa ser do usuário.' });

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        instructions: `${personas[character]}\n\n${safety}`,
        input: safeMessages,
        max_output_tokens: 700,
        store: false
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error('OpenAI API error:', response.status, data?.error?.message || 'unknown');
      return res.status(502).json({ error: 'O serviço de inteligência artificial não conseguiu responder. Tente novamente mais tarde.' });
    }
    const reply = (data.output || []).flatMap(item => item.content || []).filter(part => part.type === 'output_text').map(part => part.text).join('\n').trim();
    if (!reply) return res.status(502).json({ error: 'A IA não retornou texto nesta tentativa.' });
    return res.json({ reply });
  } catch (error) {
    console.error('Request error:', error.message);
    return res.status(400).json({ error: 'Não foi possível processar a mensagem.' });
  }
});

app.listen(PORT, () => console.log(`ALMA IA API listening on ${PORT}`));
