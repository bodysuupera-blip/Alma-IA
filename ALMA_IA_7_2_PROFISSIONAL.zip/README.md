# ALMA IA 7.2 — Profissional | Reflexão e bem-estar

## Novidades
- Mensagem do dia com reflexão diária.
- Práticas integrativas opcionais: atenção plena, aterramento sensorial, escrita e percepção corporal gentil.
- Três personagens virtuais com estilos de conversa diferentes.
- Chat exclusivamente por texto e histórico local.
- Backend Node.js usando OpenAI Responses API; chave somente no servidor.
- Orientações de segurança e limites: não é psicoterapia, não diagnostica e não substitui profissional de saúde.

## Estrutura
- `app/`: aplicativo Android e interface.
- `app/src/main/assets/images/`: retratos dos personagens virtuais.
- `backend/`: API que conecta o chat à OpenAI.
- `render.yaml`: configuração inicial para publicar no Render.
- `.github/workflows/build-apk.yml`: compilação do APK.

## Gerar APK
1. Extraia este ZIP.
2. Envie o conteúdo para a raiz do repositório GitHub.
3. Mantenha o arquivo `ALMA_IA_7_2_PROFISSIONAL.zip` na raiz se for usar o workflow que extrai o ZIP.
4. Em Actions, execute `ALMA IA 7.2 - GERAR APK`.
5. Baixe `ALMA-IA-7.2-APK-PROFISSIONAL`.

## Publicar o servidor (etapa obrigatória antes de usuários conversarem com a IA)
1. Publique a pasta `backend` no Render ou outro host Node.js. O `render.yaml` define `rootDir: backend`.
2. Configure no painel do host a variável secreta `OPENAI_API_KEY`. Nunca coloque a chave no APK ou no GitHub.
3. `OPENAI_MODEL` usa `gpt-6.2-sol` por padrão; pode ser alterado para outro modelo disponível na sua conta.
4. Após publicar, copie a URL HTTPS do serviço. Abra Ajustes no app e informe essa URL.
5. Teste a rota `/health`; ela informa `aiConfigured: true` quando a chave está configurada.

**Importante:** este ZIP deixa o backend e o app preparados, mas não publica o serviço automaticamente nem contém sua chave. O endereço definitivo do servidor só existe depois da publicação na sua conta. O uso da API pode gerar cobrança separada da assinatura do ChatGPT.

## Limites e segurança
A ALMA IA oferece apoio conversacional de reflexão e bem-estar, não tratamento clínico. Personagens são virtuais. Não diagnostica, prescreve ou substitui psicoterapia, avaliação médica ou emergência. Em risco imediato no Brasil, procure ajuda presencial e serviços de emergência (SAMU 192; perigo imediato 190; CVV 188 para apoio emocional). O histórico é salvo localmente no aparelho.
