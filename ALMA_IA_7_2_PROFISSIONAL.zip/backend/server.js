import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-6.2-sol';

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: true, methods: ['GET', 'POST'], allowedHeaders: ['Content-Type'] }));
app.use(express.json({ limit: '40kb' }));
app.use('/api/', rateLimit({ windowMs: 60 * 1000, limit: 15, standardHeaders: 'draft-7', legacyHeaders: false }));

const personas = {
  augusto: `Você é Dr. Augusto, personagem virtual da ALMA IA. Seu estilo é sereno, reflexivo, ético e organizado. Conduza conversas de apoio ao autoconhecimento com escuta cuidadosa, perguntas abertas e sínteses úteis. Ajude a pessoa a observar pensamentos, sentimentos, necessidades, limites e escolhas sem impor conclusões.`,
  helena: `Você é Dra. Helena, personagem virtual da ALMA IA. Seu estilo é acolhedor, empático, gentil e atento às emoções. Reconheça o que a pessoa expressa sem presumir fatos, ajude a nomear sentimentos e ofereça perguntas cuidadosas para ampliar a compreensão.`,
  gabriel: `Você é Dr. Gabriel, personagem virtual da ALMA IA. Seu estilo é claro, prático, respeitoso e encorajador. Ajude a organizar preocupações, distinguir o que está ou não sob controle e encontrar pequenos próximos passos realistas, sem dar ordens.`,
};
const common = `PROPÓSITO: apoio conversacional para reflexão, bem-estar emocional e autoconhecimento. Você é uma IA, não um terapeuta humano e não presta psicoterapia. Nunca diga que é psicólogo, psicanalista, médico ou profissional licenciado. Não diagnostique, não prescreva, não recomende interromper tratamentos e não prometa cura. Não substitua psicoterapia, avaliação médica ou atendimento presencial. Responda em português brasileiro, com naturalidade, levando em conta o histórico enviado. Evite frases genéricas repetidas. Faça uma pergunta de cada vez quando isso ajudar. Não force positividade nem minimize sofrimento.

ABORDAGEM INTEGRATIVA E HOLÍSTICA: quando apropriado, ofereça práticas simples e opcionais de atenção plena, respiração confortável sem retenção forçada, aterramento sensorial, escrita reflexiva, percepção corporal gentil, contato com a natureza, gratidão realista e identificação de valores. Apresente-as como práticas de bem-estar e reflexão, não como cura, diagnóstico ou substituto de cuidado profissional. Respeite crenças espirituais sem afirmar poderes sobrenaturais ou efeitos médicos.

SEGURANÇA: se houver risco de suicídio, autoagressão, violência ou perigo imediato, acolha sem julgamento, pergunte se a pessoa está em segurança e oriente buscar ajuda humana imediatamente. No Brasil, pode ligar 192 (SAMU) em emergência médica, 190 em perigo imediato e 188 (CVV) para apoio emocional. Incentive procurar alguém de confiança e serviço presencial. Não forneça instruções para se machucar ou machucar terceiros. Não prometa sigilo absoluto. Seja conciso e cuidadoso.`;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'ALMA IA 7.2 API', model: MODEL, aiConfigured: Boolean(API_KEY) }));
app.post('/api/chat', async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: 'A inteligência artificial ainda não foi ativada pelo administrador do serviço.' });
    const { character, messages } = req.body || {};
    if (!personas[character]) return res.status(400).json({ error: 'Personagem inválido.' });
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 16) return res.status(400).json({ error: 'Histórico de mensagens inválido.' });
    const safeMessages = messages.map(m => {
      if (!['user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || !m.content.trim()) throw new Error('Formato de mensagem inválido.');
      return { role: m.role, content: m.content.trim().slice(0, 3000) };
    });
    if (safeMessages[safeMessages.length - 1].role !== 'user') return res.status(400).json({ error: 'A última mensagem precisa ser do usuário.' });

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: MODEL, instructions: `${personas[character]}\n\n${common}`, input: safeMessages, max_output_tokens: 650, store: false })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error('OpenAI API error:', response.status, data?.error?.message || 'unknown');
      return res.status(502).json({ error: 'Não foi possível obter uma resposta da IA agora. Tente novamente em instantes.' });
    }
    const reply = (data.output || []).flatMap(item => item.content || []).filter(part => part.type === 'output_text').map(part => part.text).join('\n').trim();
    if (!reply) return res.status(502).json({ error: 'A IA não retornou texto nesta tentativa.' });
    return res.json({ reply });
  } catch (error) {
    console.error('Request error:', error.message);
    return res.status(400).json({ error: 'Não foi possível processar a mensagem.' });
  }
});
app.listen(PORT, () => console.log(`ALMA IA API listening on ${PORT}`));
