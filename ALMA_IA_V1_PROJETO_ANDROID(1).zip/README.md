# ALMA IA — protótipo Android

Protótipo inicial de interface de autoconhecimento com personagens demonstrativos, entrada de texto, leitura de voz do aparelho quando suportada e diário local.

## Compilar
Abra o repositório no GitHub e execute Actions → ALMA IA - GERAR APK → Run workflow.

## Limitações importantes
- As respostas são demonstrativas e pré-programadas; não existe conexão com um modelo de IA remoto.
- Os personagens são representações ilustradas por emojis, não avatares realistas em vídeo.
- Voz depende dos recursos do navegador/dispositivo.
- O diário é armazenado localmente no WebView; não há conta, sincronização ou criptografia própria.
- Não é um serviço de saúde, não diagnostica e não substitui acompanhamento profissional.
