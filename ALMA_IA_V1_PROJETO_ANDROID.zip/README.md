# ALMA IA V1.0

Projeto Android inicial do ALMA IA.

## O que já está incluído
- Interface mobile premium em português.
- Seleção de três personagens virtuais.
- Tela de conversa e respostas demonstrativas locais.
- Síntese de voz (quando disponível no aparelho/navegador).
- Reconhecimento de voz (quando suportado pelo WebView).
- Diário pessoal salvo localmente no aparelho.
- Workflow GitHub Actions para gerar APK debug.

## Gerar APK pelo GitHub
1. Envie todo o conteúdo deste ZIP para a raiz de um repositório GitHub.
2. Abra a aba Actions.
3. Se necessário, habilite workflows.
4. Execute `ALMA IA - Gerar APK`.
5. Baixe o artefato `ALMA-IA-APK`.

## Limitações importantes
Esta V1 é um protótipo funcional de interface. As respostas ainda são demonstrativas, não existe conexão com um modelo de IA remoto, e os personagens ainda não são avatares de vídeo realistas com sincronização labial.
Para ativar IA real será necessário configurar um backend seguro e uma chave de API no servidor (nunca inserir chave secreta no aplicativo). Para avatares falantes será necessária integração com um serviço de avatar/vídeo.
O diário desta versão fica no armazenamento local do aparelho. Antes de uso clínico ou comercial, implementar autenticação, criptografia, consentimento, política de privacidade, controles de retenção/exclusão e revisão profissional. Não usar para diagnóstico nem como substituto de atendimento profissional.
