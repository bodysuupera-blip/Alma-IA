# ALMA IA 2.1 — correção de áudio Android

Esta atualização usa SpeechRecognizer e TextToSpeech nativos do Android, em vez de depender de Web Speech API dentro do WebView.

## Antes de testar
- Instale o APK novo por cima do anterior (ou desinstale a versão anterior se houver conflito de assinatura).
- Permita o microfone quando solicitado.
- Para reconhecimento de fala, o aparelho precisa ter um serviço de reconhecimento instalado/ativado (geralmente Google).
- Para ouvir, verifique em Configurações Android > Sistema > Idiomas e entrada > Saída de texto para voz se há voz em português instalada.

A fala usa as vozes disponíveis no aparelho; a seleção de voz masculina/feminina ainda depende das vozes instaladas e será refinada depois.
As respostas continuam demonstrativas, sem IA remota conectada.
