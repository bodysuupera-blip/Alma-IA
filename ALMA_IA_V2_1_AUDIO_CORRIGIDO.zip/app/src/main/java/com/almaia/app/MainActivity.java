package com.almaia.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int AUDIO_REQUEST = 77;
    private WebView webView;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean pendingListen = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AudioBridge(), "AlmaAudio");
        setContentView(webView);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("pt", "BR"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                           result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startNativeRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendJs("window.onAlmaSpeechError && window.onAlmaSpeechError('O serviço de reconhecimento de voz não está disponível neste aparelho. Verifique se o app Google está instalado e atualizado.');");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_REQUEST);
            return;
        }
        if (recognizer != null) { recognizer.destroy(); recognizer = null; }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                sendJs("window.onAlmaSpeechStatus && window.onAlmaSpeechStatus('Ouvindo... fale agora.');");
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {
                sendJs("window.onAlmaSpeechStatus && window.onAlmaSpeechStatus('Processando voz...');");
            }
            @Override public void onError(int error) {
                sendJs("window.onAlmaSpeechError && window.onAlmaSpeechError('Não consegui reconhecer a fala. Tente novamente e confira a conexão e o serviço de voz do Google.');");
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String safe = matches.get(0).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                    sendJs("window.onAlmaSpeechResult && window.onAlmaSpeechResult('" + safe + "');");
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(intent);
    }

    private void sendJs(String js) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private class AudioBridge {
        @JavascriptInterface public void startListening() {
            runOnUiThread(() -> startNativeRecognition());
        }
        @JavascriptInterface public void speak(String text, boolean female) {
            runOnUiThread(() -> {
                if (tts == null || !ttsReady) {
                    Toast.makeText(MainActivity.this, "Voz em português não disponível. Instale os dados de voz do Google.", Toast.LENGTH_LONG).show();
                    return;
                }
                tts.setLanguage(new Locale("pt", "BR"));
                // A voz disponível depende das vozes instaladas no Android.
                tts.setSpeechRate(0.95f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ALMA_TTS");
            });
        }
        @JavascriptInterface public void stopSpeaking() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingListen) { pendingListen = false; startNativeRecognition(); }
            } else {
                pendingListen = false;
                sendJs("window.onAlmaSpeechError && window.onAlmaSpeechError('Permissão do microfone negada. Ative-a nas configurações do aplicativo.');");
            }
        }
    }

    @Override public void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
