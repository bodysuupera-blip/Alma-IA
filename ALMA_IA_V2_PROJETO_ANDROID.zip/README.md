# ALMA IA 2.0 — protótipo de interface

Esta versão atualiza a interface e mantém três personagens demonstrativos, diário local, leitura de texto em voz alta e reconhecimento de fala quando suportados pelo Android/WebView.

## Limitações desta etapa
- Os retratos são placeholders visuais; ainda não são fotos realistas personalizadas.
- A fala usa recursos locais do aparelho, não vozes licenciadas de personagens.
- As respostas são demonstrativas e pré-programadas; não há IA remota conectada.
- Não há vídeo, sincronização labial ou Tavus nesta versão.
- O diário fica no armazenamento local do WebView; não há sincronização ou criptografia própria.

## Compilar
O fluxo GitHub Actions `.github/workflows/build-apk.yml` compila o APK debug com Java 17 e Gradle 8.9.

Esta aplicação é experimental, não diagnostica e não substitui atendimento profissional.
