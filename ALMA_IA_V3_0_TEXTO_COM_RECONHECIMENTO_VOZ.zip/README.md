# ALMA IA 3.0

Evolução do projeto Android ALMA IA V1 enviado pelo usuário.

## Atualizações desta versão
- Identidade visual renovada em azul profundo, ciano e dourado.
- Retratos fotorealistas de personagens fictícios: Dr. Augusto, Dra. Helena e Dr. Gabriel.
- Retratos aparecem na seleção de personagens e no cabeçalho da conversa.
- Mantidas as telas de conversa demonstrativa, diário local, reflexão guiada e sobre.
- Versão Android atualizada para 3.0 (versionCode 3).

## Importante
As conversas continuam sendo demonstrativas e locais, herdadas da V1. Não há conexão com um modelo de IA remoto nesta entrega. Os retratos são imagens ilustrativas de personagens fictícios, não fotografias de profissionais reais. O diário permanece salvo localmente no aparelho. Antes de uso comercial ou clínico, implementar backend seguro, autenticação, criptografia, consentimento e política de privacidade.

## Gerar APK
Envie os arquivos para a raiz do repositório GitHub, abra Actions e execute **ALMA IA - Gerar APK**. O APK debug será publicado no artefato **ALMA-IA-APK**.
