# MENTEX NEXT — novo jogo Android

Projeto independente, criado para não misturar arquivos, identificadores ou workflows com outros jogos do repositório.

## Identidade independente
- Nome: MENTEX NEXT
- Pacote Android: `br.com.superagames.mentexnext`
- Módulo: `app`
- Workflow: `.github/workflows/mentex-next-android.yml`
- `applicationId` próprio; não reutiliza o identificador do MenteX antigo nem de Cão Fujão.

## O que já está no projeto
- Introdução de boas-vindas com mascote-cérebro estilizado e animação de entrada/pulso.
- Tela inicial de jogo.
- Quiz com quatro alternativas, retorno de acerto/erro e explicação.
- Progressão local por 250 fases (perguntas de demonstração geradas por categoria; substitua pelo banco editorial final antes de publicar).
- Perfil e estatísticas locais.
- Ranking demonstrativo local.
- Loja demonstrativa e botão de recompensa de demonstração.
- Navegação inferior e interface azul/roxa.
- Workflow GitHub Actions para compilar APK Debug e publicar artefato.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
- Gradle Wrapper incluído

## Gerar APK
Abra a pasta do projeto no Android Studio e execute `assembleDebug`, ou envie o conteúdo para um repositório GitHub novo e execute o workflow `MENTEX NEXT — Gerar APK`.

O APK de depuração ficará em:
`app/build/outputs/apk/debug/app-debug.apk`

## Integrações que exigem configuração externa
As compras Google Play, anúncios recompensados, login online, ranking global e convites com atribuição ainda precisam de IDs, produtos, credenciais e backend próprios. O projeto deixa pontos de integração e não simula compras reais. Não publique com IDs de teste.

### Próximas configurações necessárias
1. Criar um app novo no Google Play Console com o pacote `br.com.superagames.mentexnext`.
2. Cadastrar produtos de compra única para moedas e configurar Billing.
3. Criar unidade de anúncio recompensado no AdMob e substituir o ID de teste.
4. Configurar Firebase (Authentication/Firestore) se quiser login e ranking online.
5. Trocar perguntas demonstrativas por conteúdo original revisado.
