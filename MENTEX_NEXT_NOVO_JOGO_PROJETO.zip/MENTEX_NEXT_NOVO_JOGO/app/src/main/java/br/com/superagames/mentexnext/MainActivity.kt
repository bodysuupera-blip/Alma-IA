package br.com.superagames.mentexnext

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF080D20)
private val Panel = Color(0xFF121B38)
private val Blue = Color(0xFF35B5FF)
private val Violet = Color(0xFF9B68FF)
private val Aqua = Color(0xFF52E6C2)
private val TextMain = Color(0xFFF5F6FF)
private val TextSoft = Color(0xFFABB6D2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("mentex_next", Context.MODE_PRIVATE)
        setContent {
            MentexTheme {
                GameApp(
                    initialPhase = prefs.getInt("phase", 1),
                    initialXp = prefs.getInt("xp", 0),
                    initialCoins = prefs.getInt("coins", 250),
                    onSave = { phase, xp, coins ->
                        prefs.edit().putInt("phase", phase).putInt("xp", xp)
                            .putInt("coins", coins).apply()
                    }
                )
            }
        }
    }
}

@Composable
private fun MentexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, secondary = Violet, background = Night,
            surface = Panel, onPrimary = Color.White, onBackground = TextMain,
            onSurface = TextMain
        ),
        content = content
    )
}

private enum class Tab(val title: String) {
    HOME("Início"), GAME("Jogar"), RANK("Ranking"), STORE("Loja"), PROFILE("Perfil")
}

private data class Question(
    val category: String,
    val prompt: String,
    val options: List<String>,
    val correct: Int,
    val explanation: String
)

private val questionBank = listOf(
    Question("Conhecimentos gerais", "Qual é o maior planeta do Sistema Solar?",
        listOf("Terra", "Júpiter", "Marte", "Saturno"), 1,
        "Júpiter é o maior planeta do Sistema Solar."),
    Question("Ciência", "Qual é a principal função dos pulmões?",
        listOf("Bombear sangue", "Filtrar alimentos", "Realizar trocas gasosas", "Produzir hormônios"), 2,
        "Os pulmões realizam as trocas de oxigênio e gás carbônico."),
    Question("Matemática", "Quanto é 12 × 8?",
        listOf("86", "92", "96", "108"), 2,
        "12 multiplicado por 8 é igual a 96."),
    Question("Geografia", "Qual é o maior oceano da Terra?",
        listOf("Atlântico", "Índico", "Ártico", "Pacífico"), 3,
        "O Oceano Pacífico é o maior e mais profundo oceano."),
    Question("Lógica", "Qual número completa a sequência: 2, 4, 8, 16, ...?",
        listOf("18", "24", "30", "32"), 3,
        "Cada número é o dobro do anterior: 16 × 2 = 32."),
    Question("História", "Em qual país surgiram os Jogos Olímpicos antigos?",
        listOf("Itália", "Grécia", "Egito", "China"), 1,
        "Os Jogos Olímpicos antigos tiveram origem na Grécia."),
    Question("Linguagem", "Qual palavra é um sinônimo de ' veloz'?",
        listOf("Lento", "Rápido", "Distante", "Silencioso"), 1,
        "Rápido é um sinônimo de veloz."),
    Question("Natureza", "Qual destes animais é um mamífero?",
        listOf("Tubarão", "Sapo", "Golfinho", "Tartaruga"), 2,
        "Golfinhos são mamíferos: respiram ar e amamentam seus filhotes.")
)

private fun questionForPhase(phase: Int): Question {
    // Banco inicial demonstrativo; amplia-se com perguntas editoriais sem alterar o motor das 250 fases.
    return questionBank[(phase - 1) % questionBank.size]
}

@Composable
private fun GameApp(
    initialPhase: Int, initialXp: Int, initialCoins: Int,
    onSave: (Int, Int, Int) -> Unit
) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var introDone by remember { mutableStateOf(false) }
    var phase by remember { mutableIntStateOf(initialPhase.coerceIn(1, 250)) }
    var xp by remember { mutableIntStateOf(initialXp) }
    var coins by remember { mutableIntStateOf(initialCoins) }
    var correctCount by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var resultVisible by remember { mutableStateOf(false) }
    var lastCorrect by remember { mutableStateOf(false) }
    var displayName by remember { mutableStateOf("Explorador") }

    LaunchedEffect(phase, xp, coins) { onSave(phase, xp, coins) }

    Box(Modifier.fillMaxSize().background(Night)) {
        AnimatedContent(
            targetState = introDone,
            transitionSpec = { fadeIn(tween(650)) togetherWith fadeOut(tween(300)) },
            label = "welcome"
        ) { entered ->
            if (!entered) WelcomeScreen(onStart = { introDone = true })
            else Column(Modifier.fillMaxSize()) {
                Header(coins = coins, onProfile = { tab = Tab.PROFILE })
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        Tab.HOME -> HomeScreen(
                            name = displayName, phase = phase, xp = xp, coins = coins,
                            onPlay = { selected = -1; resultVisible = false; tab = Tab.GAME },
                            onDaily = { coins += 20 },
                            onInvite = { tab = Tab.PROFILE }
                        )
                        Tab.GAME -> {
                            if (resultVisible) {
                                AnswerScreen(
                                    correct = lastCorrect,
                                    explanation = questionForPhase(phase).explanation,
                                    onNext = {
                                        if (lastCorrect) {
                                            correctCount++
                                            xp += 25
                                            coins += 10
                                        }
                                        if (phase < 250) phase++ else phase = 1
                                        selected = -1
                                        resultVisible = false
                                    }
                                )
                            } else QuizScreen(
                                phase = phase,
                                question = questionForPhase(phase),
                                selected = selected,
                                onSelect = { selected = it },
                                onConfirm = {
                                    if (selected >= 0) {
                                        lastCorrect = selected == questionForPhase(phase).correct
                                        resultVisible = true
                                    }
                                }
                            )
                        }
                        Tab.RANK -> RankingScreen()
                        Tab.STORE -> StoreScreen(coins = coins, onDemoReward = { coins += 30 })
                        Tab.PROFILE -> ProfileScreen(
                            name = displayName, phase = phase, xp = xp, coins = coins,
                            correct = correctCount,
                            onNameChange = { displayName = it }
                        )
                    }
                }
                NavigationBar(containerColor = Color(0xFF0D1530), contentColor = TextMain) {
                    Tab.values().forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        Tab.HOME -> Icons.Default.Home
                                        Tab.GAME -> Icons.Default.Psychology
                                        Tab.RANK -> Icons.Default.Leaderboard
                                        Tab.STORE -> Icons.Default.Store
                                        Tab.PROFILE -> Icons.Default.Person
                                    }, contentDescription = item.title
                                )
                            },
                            label = { Text(item.title, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Blue, selectedTextColor = Blue,
                                indicatorColor = Color(0xFF1B2A50), unselectedIconColor = TextSoft
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onStart: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "brainPulse")
    val pulse by infinite.animateFloat(
        initialValue = 0.96f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    var showText by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(450); showText = true }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF111C43), Night, Color(0xFF1B1240)))
        ).padding(26.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("MENTEX", color = TextMain, fontSize = 36.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
            Text("NEXT GENERATION", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Spacer(Modifier.height(48.dp))
            Box(
                Modifier.size(190.dp).scale(pulse).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF5548B9), Color(0xFF172B65), Color.Transparent))),
                contentAlignment = Alignment.Center
            ) {
                Text("🧠", fontSize = 105.sp)
            }
            Spacer(Modifier.height(35.dp))
            AnimatedVisibility(showText, enter = fadeIn(tween(900)) + slideInVertically()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Olá, explorador!", color = TextMain, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Bem-vindo ao MENTEX NEXT.\nPrepare sua mente: são 250 fases de desafios,\ndescobertas e evolução.",
                        color = TextSoft, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp
                    )
                    Spacer(Modifier.height(30.dp))
                    Button(
                        onClick = onStart,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue),
                        shape = RoundedCornerShape(17.dp)
                    ) {
                        Text("COMEÇAR JORNADA", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.Default.ArrowForward, null)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(coins: Int, onProfile: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BrainBadge()
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("MENTEX", color = TextMain, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 2.sp)
            Text("N E X T", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        }
        Surface(color = Panel, shape = CircleShape) {
            Text("🪙 $coins", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = TextMain, fontWeight = FontWeight.Bold)
        }
        IconButton(onClick = onProfile) { Icon(Icons.Default.AccountCircle, null, tint = TextSoft) }
    }
}

@Composable
private fun BrainBadge() {
    Box(
        Modifier.size(43.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Blue, Violet))),
        contentAlignment = Alignment.Center
    ) { Text("🧠", fontSize = 25.sp) }
}

@Composable
private fun HomeScreen(
    name: String, phase: Int, xp: Int, coins: Int,
    onPlay: () -> Unit, onDaily: () -> Unit, onInvite: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF15366D), Color(0xFF432D7A), Color(0xFF17244B))))
                    .padding(20.dp)
            ) {
                Column {
                    Text("PENSE • DESAFIE • EVOLUA", color = Aqua, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Spacer(Modifier.height(9.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Olá, $name!", color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Seu próximo nível começa agora.", color = TextSoft, fontSize = 12.sp)
                            Spacer(Modifier.height(17.dp))
                            Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                                Text("JOGAR AGORA", fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(5.dp))
                                Icon(Icons.Default.PlayArrow, null)
                            }
                        }
                        Text("🧠", fontSize = 66.sp)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MetricCard("FASE", "$phase/250", "🏁", Modifier.weight(1f))
                MetricCard("XP", xp.toString(), "⚡", Modifier.weight(1f))
                MetricCard("MOEDAS", coins.toString(), "🪙", Modifier.weight(1f))
            }
        }
        item {
            Text("SUA JORNADA", color = TextMain, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Progresso das fases", color = TextMain, fontWeight = FontWeight.Bold)
                        Text("${phase - 1} de 250", color = Blue, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { (phase - 1) / 250f },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                        color = Blue, trackColor = Color(0xFF283354)
                    )
                    Spacer(Modifier.height(7.dp))
                    Text("Avance fase por fase e desbloqueie novos desafios.", color = TextSoft, fontSize = 11.sp)
                }
            }
        }
        item {
            Text("MODOS DE DESAFIO", color = TextMain, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            Text("O motor de fases está pronto para receber categorias e perguntas novas.", color = TextSoft, fontSize = 11.sp)
            listOf(
                "🧩" to ("Raciocínio lógico" to "Sequências, padrões e estratégia"),
                "🧠" to ("Memória" to "Atenção e memorização"),
                "🌎" to ("Conhecimentos gerais" to "Ciência, história e mundo"),
                "⏱️" to ("Desafio contra o tempo" to "Responda antes do cronômetro")
            ).forEach { (emoji, pair) ->
                Surface(onClick = onPlay, color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(emoji, fontSize = 26.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(pair.first, color = TextMain, fontWeight = FontWeight.Bold)
                            Text(pair.second, color = TextSoft, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Blue)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onDaily, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.CardGiftcard, null); Spacer(Modifier.width(4.dp)); Text("Bônus diário")
                }
                OutlinedButton(onClick = onInvite, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.GroupAdd, null); Spacer(Modifier.width(4.dp)); Text("Amigos")
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, icon: String, modifier: Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(11.dp)) {
            Text(icon, fontSize = 17.sp)
            Text(value, color = TextMain, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            Text(title, color = TextSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun QuizScreen(
    phase: Int, question: Question, selected: Int,
    onSelect: (Int) -> Unit, onConfirm: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("FASE $phase DE 250", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { phase / 250f }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = Violet, trackColor = Color(0xFF283354)
        )
        Spacer(Modifier.height(22.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🧠", fontSize = 58.sp)
                Text("Vamos pensar juntos!", color = Violet, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(question.category.uppercase(), color = Aqua, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(question.prompt, color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 29.sp)
        Spacer(Modifier.height(18.dp))
        question.options.forEachIndexed { index, option ->
            val active = selected == index
            Surface(
                onClick = { onSelect(index) },
                color = if (active) Color(0xFF243D72) else Panel,
                shape = RoundedCornerShape(14.dp),
                border = if (active) BorderStroke(1.dp, Blue) else null,
                modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${'A' + index}", color = Blue, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(13.dp))
                    Text(option, color = TextMain, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    if (active) Icon(Icons.Default.CheckCircle, null, tint = Aqua)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onConfirm, enabled = selected >= 0,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(15.dp)
        ) { Text("CONFIRMAR RESPOSTA", fontWeight = FontWeight.Black) }
    }
}

@Composable
private fun AnswerScreen(correct: Boolean, explanation: String, onNext: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(if (correct) "🥳" else "🤔", fontSize = 78.sp)
        Text(
            if (correct) "ACERTOU!" else "NÃO DESISTA!",
            color = if (correct) Aqua else Color(0xFFFFC857),
            fontSize = 29.sp, fontWeight = FontWeight.Black
        )
        Text(
            if (correct) "Seu cérebro está evoluindo!" else "Cada tentativa é uma oportunidade de aprender.",
            color = TextSoft, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(22.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("ENTENDA A RESPOSTA", color = Blue, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text(explanation, color = TextMain)
            }
        }
        Spacer(Modifier.height(26.dp))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text("PRÓXIMA FASE")
        }
    }
}

@Composable
private fun RankingScreen() {
    val rows = listOf("1" to ("Ana Gamer" to "2.450 XP"), "2" to ("Lucas Brain" to "2.180 XP"),
        "3" to ("Você" to "1.920 XP"), "4" to ("Marina" to "1.760 XP"), "5" to ("Pedro" to "1.420 XP"))
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("RANKING", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("Dispute posições e evolua a cada desafio.", color = TextSoft)
        Spacer(Modifier.height(18.dp))
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🏆", fontSize = 48.sp)
                Text("TEMPORADA DE DESAFIOS", color = Blue, fontWeight = FontWeight.Bold)
                Text("Prévia visual — ranking online requer backend e contas.", color = TextSoft, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        rows.forEach { (rank, user) ->
            Surface(color = if (user.first == "Você") Color(0xFF203765) else Panel,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(rank, color = if (rank == "1") Color(0xFFFFC857) else TextSoft, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Spacer(Modifier.width(14.dp))
                    Text("👤", fontSize = 20.sp)
                    Spacer(Modifier.width(10.dp))
                    Text(user.first, Modifier.weight(1f), color = TextMain, fontWeight = FontWeight.Bold)
                    Text(user.second, color = Aqua, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StoreScreen(coins: Int, onDemoReward: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Text("LOJA MENTEX", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("Recompensas e itens para sua jornada", color = TextSoft)
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(19.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("SUA CARTEIRA", color = Blue, fontWeight = FontWeight.Bold)
                    Text("🪙 $coins moedas", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("Saldo salvo neste aparelho.", color = TextSoft, fontSize = 11.sp)
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("▶️", fontSize = 28.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Anúncio recompensado", color = TextMain, fontWeight = FontWeight.Bold)
                        Text("Botão demonstrativo: integração AdMob pendente.", color = TextSoft, fontSize = 10.sp)
                    }
                    Button(onClick = onDemoReward) { Text("+30") }
                }
            }
        }
        item { Text("PACOTES (CATÁLOGO VISUAL)", color = Violet, fontWeight = FontWeight.Bold) }
        items(listOf("1.000 moedas" to "R$ 4,90", "5.000 moedas" to "R$ 9,90", "10.000 moedas" to "R$ 19,90")) { item ->
            Surface(color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🪙", fontSize = 25.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(item.first, Modifier.weight(1f), color = TextMain, fontWeight = FontWeight.Bold)
                    Text(item.second, color = Aqua, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Text("Compras Google Play não estão ativadas neste protótipo. Cadastre os produtos no Play Console e implemente Billing antes de vender.", color = TextSoft, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ProfileScreen(
    name: String, phase: Int, xp: Int, coins: Int, correct: Int,
    onNameChange: (String) -> Unit
) {
    var editName by remember { mutableStateOf(name) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Text("MEU PERFIL", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(12.dp))
            Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🧠", fontSize = 58.sp)
                    Text(name, color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    Text("JOGADOR • NÍVEL ${(xp / 100) + 1}", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            OutlinedTextField(
                value = editName, onValueChange = { editName = it },
                label = { Text("Nome do jogador") }, modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Button(onClick = { onNameChange(editName.ifBlank { "Explorador" }) }, modifier = Modifier.fillMaxWidth()) {
                Text("SALVAR NOME")
            }
        }
        item {
            Text("ESTATÍSTICAS", color = Violet, fontWeight = FontWeight.Bold)
            listOf("Fase atual" to "$phase / 250", "Experiência" to "$xp XP", "Moedas" to "$coins", "Respostas corretas nesta sessão" to "$correct").forEach { stat ->
                Surface(color = Panel, shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth().padding(top = 7.dp)) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stat.first, color = TextSoft)
                        Text(stat.second, color = TextMain, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Text("Login, sincronização em nuvem e perfil público precisam de autenticação e backend.", color = TextSoft, fontSize = 10.sp)
        }
    }
}
