# MENTEX

Projeto Android independente do jogo MENTEX.

- Nome exibido: **MENTEX** (sem NEXT ou 4.0 no título do aplicativo).
- 250 desafios únicos com progressão de dificuldade e sequência contínua de fases.
- Mascote cerebral com animação de pulsação na abertura, durante o desafio e no feedback.
- Resposta correta e incorreta exibem explicação e incentivam a progressão.
- Progresso, XP e moedas salvos localmente.

## Gerar APK
O workflow GitHub Actions extrai este projeto e executa `assembleDebug`. O APK de depuração é publicado como artefato.

Observação: ranking online, anúncios e compras Google Play ainda exigem serviços e credenciais próprios; não estão ativados nesta versão.
