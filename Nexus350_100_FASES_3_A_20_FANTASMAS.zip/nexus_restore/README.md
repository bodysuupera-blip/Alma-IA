# Nexus 350 - Labirinto de Fantasmas


Reconstituição dos arquivos web presentes no APK enviado, mantendo a lógica e o visual original do jogo.


## Fonte
- `www/index.html`
- `www/game.js`
- `www/style.css`
- `www/welcome.png`

## Gerar APK
O workflow em `.github/workflows/android-apk.yml` prepara a plataforma Android e compila o APK debug.


Atualização de fases: 100 fases. Os fantasmas começam em 3 e aumentam progressivamente até 20 na fase 100. Formato, controle e ritmo de jogo mantidos.
