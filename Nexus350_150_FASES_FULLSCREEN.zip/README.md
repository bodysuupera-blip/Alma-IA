# Nexus 350 - Labirinto de Fantasmas (V6)
- 150 fases; progressao de fantasmas de 3 a 20.
- Tela inicial nova com titulo e botao Iniciar; sem regras.
- Layout fullscreen, travado horizontal no workflow Android.
- Botao de anuncio recompensado demonstrativo no game over: resgate +3 vidas.
  **Nota:** anuncio real ainda depende de integrar SDK de anuncios recompensados.
- ZIP pronto para extrair na raiz do repositorio ou usar o workflow incluido.
