# Nexus 350 — 150 fases, horizontal e tela cheia

- 150 fases, progressão de 3 a 20 fantasmas.
- Tela Android em landscape, fullscreen/immersive (aplicada no workflow após gerar Android).
- Ícone redondo sem textos para o launcher.
- Tela inicial e jogo da fonte atual mantidos.
- Botão de vidas +3 existente está em modo demonstrativo; anúncio real requer SDK/AdMob.

## Build
Use o workflow incluído em `.github/workflows/android-apk.yml`. O ZIP precisa ser colocado na raiz do repositório, com o mesmo nome definido no workflow.
