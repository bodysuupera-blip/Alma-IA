# Nexus 350 — Labirinto de Fantasmas

Fonte com nova tela de boas-vindas integrada, regras visíveis e botão de iniciar. Mantém 100 fases, progressão de 3 até 20 fantasmas e gameplay/controle existentes. O workflow Android fixa a orientação em landscape e compila com Java 21.

Coloque o ZIP no repositório, execute o workflow em Actions e baixe o APK em Artifacts.
