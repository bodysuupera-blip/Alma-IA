# Nexus 350 — Labirinto de Fantasmas (fonte nova)

Fonte organizada na raiz do repositório para o GitHub Actions.

- 100 fases
- Fase 1 começa com 3 fantasmas
- Progressão gradual até 20 fantasmas na fase 100
- Mantém o layout horizontal, joystick, ritmo e mecânica existentes
- HTML, CSS e JavaScript em `www/`


## Build
O workflow `.github/workflows/android-apk.yml` instala as dependências, cria/sincroniza a plataforma Android e gera o APK debug como artifact.
