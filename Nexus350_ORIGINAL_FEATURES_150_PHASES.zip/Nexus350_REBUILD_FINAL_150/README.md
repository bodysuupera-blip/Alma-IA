# Nexus 350 — reconstrução 150 fases

Fonte independente do jogo anterior, em HTML/CSS/Canvas, preservando menu de loja, perfil, convite, áudio e controles.\n

- 150 fases: ghost count escalonado de 3 a 20
- Campo aberto, sem barreiras internas
- Jogador à esquerda, chave à direita, porta à esquerda para retorno
- Coletar moedas (+10), compra interna de vidas (10 por 600), upgrade de velocidade (450)
- Loja apresenta compra de 10.000 moedas (Google Play Billing ainda não integrado)
- Recompensa de 3 vidas no game over em modo demonstração (AdMob não integrado)
- Invite usa compartilhamento nativo quando disponível
- Sons gerados por Web Audio; música de fundo procedural
- Capa com botão JOGAR; orientação horizontal nativa configurada pelo workflow

Workflow: `.github/workflows/android-apk.yml`
