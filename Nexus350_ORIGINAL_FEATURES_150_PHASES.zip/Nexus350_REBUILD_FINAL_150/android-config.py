#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image

NS='http://schemas.android.com/apk/res/android'
ET.register_namespace('android',NS)
manifest=Path('android/app/src/main/AndroidManifest.xml')
tree=ET.parse(manifest); root=tree.getroot(); app=root.find('application')
if app is None: raise SystemExit('application missing')
launcher=[]
for a in app.findall('activity'):
  for f in a.findall('intent-filter'):
    actions=[e.get(f'{{{NS}}}name') for e in f.findall('action')]
    cats=[e.get(f'{{{NS}}}name') for e in f.findall('category')]
    if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats: launcher.append(a)
if not launcher: raise SystemExit('launcher activity missing')
for a in launcher: a.set(f'{{{NS}}}screenOrientation','landscape')
app.set(f'{{{NS}}}icon','@mipmap/ic_launcher'); app.set(f'{{{NS}}}roundIcon','@mipmap/ic_launcher_round')
tree.write(manifest,encoding='utf-8',xml_declaration=True); ET.parse(manifest)
icon=Image.open('icon-round.png').convert('RGBA')
for density,size in {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}.items():
 p=Path(f'android/app/src/main/res/mipmap-{density}');p.mkdir(parents=True,exist_ok=True)
 resized=icon.resize((size,size),Image.Resampling.LANCZOS);resized.save(p/'ic_launcher.png');resized.save(p/'ic_launcher_round.png')
print('Landscape manifest and icons set')
