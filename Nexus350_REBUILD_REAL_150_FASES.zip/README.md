# Nexus 350 - Rebuild real da fonte (150 fases)

Fonte nova do jogo, com gameplay implementada em Canvas/JavaScript e sem reaproveitar a interface antiga de Pac-Man.

- Tela de abertura: arte, nome do jogo e botão JOGAR.
- Android em landscape e modo tela cheia são aplicados no workflow.
- Labirinto procedural com chave e porta, moedas e ghosts perseguindo o personagem.
- Joystick virtual na lateral esquerda; teclado (setas/WASD) para teste no navegador.
- 150 fases; fase 1 tem 3 fantasmas e fase 150 tem 20.
- Recuperação de +3 vidas depois de perder todas: demonstrativa, ainda não é anúncio real.

Para gerar APK: copie o conteúdo do ZIP para a raiz do repositório e execute o workflow Actions.
