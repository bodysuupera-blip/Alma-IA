from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw

ANDROID_NS = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ANDROID_NS)
manifest = Path('android/app/src/main/AndroidManifest.xml')
tree = ET.parse(manifest)
root = tree.getroot()
app = root.find('application')
if app is None:
    raise SystemExit('AndroidManifest: <application> ausente')
app.set(f'{{{ANDROID_NS}}}icon', '@mipmap/ic_launcher')
app.set(f'{{{ANDROID_NS}}}roundIcon', '@mipmap/ic_launcher_round')
launcher = []
for activity in app.findall('activity'):
    for intent in activity.findall('intent-filter'):
        actions = [n.get(f'{{{ANDROID_NS}}}name') for n in intent.findall('action')]
        categories = [n.get(f'{{{ANDROID_NS}}}name') for n in intent.findall('category')]
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:
            launcher.append(activity)
if not launcher:
    raise SystemExit('Activity MAIN/LAUNCHER não encontrada')
for activity in launcher:
    activity.set(f'{{{ANDROID_NS}}}screenOrientation', 'landscape')
tree.write(manifest, encoding='utf-8', xml_declaration=True)
ET.parse(manifest)  # fail fast if malformed

# Immersive fullscreen: add method to generated MainActivity, only once.ase = Path('android/app/src/main/java')
main = next(base.rglob('MainActivity.java'), None)
if main is None:
    raise SystemExit('MainActivity.java não encontrada')
s = main.read_text()
if 'nexusImmersive' not in s:
    package_line = s.find(';')
    imports = '\nimport android.os.Bundle;\nimport android.view.View;\nimport android.view.WindowManager;\n'
    if package_line >= 0:
        s = s[:package_line + 1] + imports + s[package_line + 1:]
    method = '''\n  private void nexusImmersive() {\n    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);\n    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);\n  }\n  @Override public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); nexusImmersive(); }\n  @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) nexusImmersive(); }\n'''
    end = s.rfind('}')
    s = s[:end] + method + s[end:]
    main.write_text(s)

# Circular icon in Android density folders. The source is already an icon illustration;
# apply a transparent circle crop and preserve its original visual artwork.
icon = Image.open('icon-round.png').convert('RGBA').resize((1024, 1024), Image.Resampling.LANCZOS)
mask = Image.new('L', (1024, 1024), 0)
ImageDraw.Draw(mask).ellipse((6, 6, 1018, 1018), fill=255)
icon.putalpha(mask)
for density, size in {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}.items():
    directory = Path(f'android/app/src/main/res/mipmap-{density}')
    directory.mkdir(parents=True, exist_ok=True)
    image = icon.resize((size, size), Image.Resampling.LANCZOS)
    image.save(directory / 'ic_launcher.png')
    image.save(directory / 'ic_launcher_round.png')
print('Android: manifest XML válido, landscape e fullscreen aplicados; ícone redondo atualizado.')
